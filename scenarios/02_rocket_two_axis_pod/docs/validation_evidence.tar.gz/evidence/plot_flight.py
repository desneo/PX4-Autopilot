from pathlib import Path
import json,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
run=Path('/tmp/scenario02_motion_head_5a29c7e/flight_surface_pose')
report=json.loads((run/'flight_summary.json').read_text())
assert report['passed']
rows=[json.loads(l) for l in (run/'gazebo_truth.jsonl').read_text().splitlines()]
a=[r for r in rows if r['model']=='rocket_two_axis_pod_1']; b=[r for r in rows if r['model']=='rocket_two_axis_pod_2']
p=np.array([r['nominal_cg_enu_m'] for r in a]); other=np.array(b[0]['nominal_cg_enu_m'])-p[0];p-=p[0].copy()
t=np.array([r['sim_time_s'] for r in a]);t-=t[0]
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,(ax,alt)=plt.subplots(1,2,figsize=(9.6,4.8),layout='constrained')
route=np.array([[0,0],[0,20],[20,20],[20,0],[0,0]])
ax.plot(route[:,0],route[:,1],color='#929bad',ls='--',lw=1.4,label='20 m planned route')
ax.plot(p[:,0],p[:,1],color='#137cba',lw=2,label='UAV 1: Gazebo CG')
ax.scatter(*p[0,:2],color='#2c9c60',s=40,zorder=4,label='Start / landed')
ax.scatter(*other[:2],marker='D',color='#b7741f',s=32,label='UAV 2: stationary')
ax.set(xlabel='East relative to start (m)',ylabel='North relative to start (m)',title='PX4 scenario 02: native MAVSDK mission',xlim=(-3,24),ylim=(-3,24))
ax.set_aspect('equal'); ax.grid(alpha=.18);ax.legend(fontsize=8,loc='upper center',bbox_to_anchor=(.5,-.17),ncol=2,frameon=False)
alt.plot(t,p[:,2],color='#137cba',lw=2)
alt.axhline(15,color='#929bad',ls='--',lw=1.3,label='15 m mission altitude')
alt.set(xlabel='Simulation time since recording (s)',ylabel='CG height above initial CG (m)',title='Climb, route, RTL and landing',ylim=(-.5,18))
alt.grid(alpha=.18);alt.legend(fontsize=8)
fig.suptitle('New two-axis pod assembly · asset 5a29c7e',fontsize=12)
out=Path(sys.argv[1]);out.parent.mkdir(parents=True,exist_ok=True);fig.savefig(out,dpi=160)
print(out)
