#!/usr/bin/env python3
"""运行既有受保护完整航线，并独立采集Gazebo电机与接触；仅--execute启动控制。"""
import argparse,hashlib,json,os,signal,subprocess,time,math,xml.etree.ElementTree as ET
from pathlib import Path
BASE=Path('/tmp/scenario02_motion_head_5a29c7e')
PYTHON='/home/aeroarx/zsh/px4-gazebo-assets/.venv-linux/bin/python'
RUNTIME=Path('/tmp/px4-scenarios/02_rocket_two_axis_pod')
STOP=False

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--output',type=Path,required=True)
 a=p.parse_args()
 if not a.execute:p.error('须显式--execute才会飞行')
 if a.output.exists() and any(a.output.iterdir()):raise RuntimeError('拒绝覆盖已有运行输出')
 a.output.mkdir(parents=True,exist_ok=True)
 old=json.loads((BASE/'flight/runtime_before_flight.json').read_text());paths=[Path(x)for x in old['source_sha256']]
 paths += [Path(__file__),BASE/'flight/collect_motor_truth.py',Path('/home/aeroarx/zsh/PX4-Autopilot/scenarios/02_rocket_two_axis_pod/prepare_world.py'),Path('/home/aeroarx/zsh/PX4-Autopilot/scenarios/02_rocket_two_axis_pod/start.sh')]
 fingerprint={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in paths if x.exists()}
 root=ET.parse(RUNTIME/'world.sdf').getroot()
 poses={m.attrib.get('name'):m.findtext('pose')for m in root.findall('./world/model')if m.attrib.get('name')in ('rocket_two_axis_pod_1','rocket_two_axis_pod_2')}
 (a.output/'runtime_before_flight.json').write_text(json.dumps(dict(captured_at_unix_s=time.time(),source_sha256=fingerprint,
       initial_spawn_poses=poses,partition=os.environ.get('GZ_PARTITION'),runtime=str(RUNTIME),
       asset_commit=subprocess.check_output(['git','-C','/home/aeroarx/zsh/px4-gazebo-assets','rev-parse','HEAD'],text=True).strip()),indent=2)+'\n')
 log=(a.output/'collector.log').open('w');collector=flight=None
 try:
  collector=subprocess.Popen([PYTHON,'-u',str(BASE/'flight/collect_motor_truth.py'),'--output',str(a.output/'motors'),'--duration','1200'],stdout=log,stderr=subprocess.STDOUT)
  start=time.monotonic()
  while not (a.output/'motors/collection_metadata.json').exists():
   if collector.poll() is not None or time.monotonic()-start>10 or STOP:raise RuntimeError('采集器未就绪，未开始控制')
   time.sleep(.1)
  time.sleep(4.)
  if STOP:raise RuntimeError('收到停止请求，未开始控制')
  pose_rows=[json.loads(line) for line in (a.output/'motors/model_truth.jsonl').read_text().splitlines() if line.endswith('}')]
  if not pose_rows:raise RuntimeError('缺少新鲜双机姿态，未开始控制')
  latest=max(row['wall_time_unix_s'] for row in pose_rows)
  recent=[row for row in pose_rows if row['wall_time_unix_s']>=latest-1.]
  tilt={}
  for row in recent:
   w,x,y,z=row['quaternion_wxyz'];angle=math.degrees(math.acos(max(-1.,min(1.,1.-2.*(x*x+y*y)))))
   tilt[row['model']]=max(tilt.get(row['model'],0.),angle)
  contact_file=a.output/'motors/contacts.jsonl';contact_force_max=0.
  if contact_file.exists():
   for line in contact_file.read_text().splitlines():
    try:row=json.loads(line)
    except json.JSONDecodeError:continue
    if row['wall_time_unix_s']<latest-1.:continue
    for contact in row['payload'].get('contact',[]):
     for wrench in contact.get('wrench',[]):
      force=wrench.get('body_1_wrench',{}).get('force',{})
      contact_force_max=max(contact_force_max,math.sqrt(sum(force.get(axis,0.)**2 for axis in ('x','y','z'))))
  preflight=dict(max_last_second_tilt_deg=tilt,max_last_second_contact_force_n=contact_force_max,
                 tilt_health_gate_deg=10.,contact_health_gate_n=5000.,
                 passed=len(tilt)==2 and max(tilt.values())<=10. and contact_force_max<=5000.)
  (a.output/'ground_health_before_control.json').write_text(json.dumps(preflight,indent=2)+'\n')
  print('解锁前真实地面健康检查 '+json.dumps(preflight),flush=True)
  if not preflight['passed']:raise RuntimeError('出生落地姿态或接触异常，拒绝带病起飞；未启动MAVSDK')
  print('同步转子/接触采集就绪；启动原完整MAVSDK航线',flush=True)
  flight=subprocess.Popen([PYTHON,'-u',str(BASE/'flight/verify_flight.py'),'--execute','--output',str(a.output)])
  print(f'flight_pid={flight.pid} collector_pid={collector.pid}',flush=True)
  stop_sent=False
  while flight.poll() is None:
   if (STOP or collector.poll() is not None) and not stop_sent:
    print('请求保护包装进行自主RTL/LAND恢复，等待其地面确认',flush=True);flight.send_signal(signal.SIGTERM);stop_sent=True
   time.sleep(.5)
  print(f'flight_exit={flight.returncode}',flush=True)
  return flight.returncode
 finally:
  if collector and collector.poll() is None:collector.send_signal(signal.SIGTERM)
  if collector:
   try:collector.wait(timeout=10)
   except subprocess.TimeoutExpired:print('只读采集器未及时退出，保留进程',flush=True)
  log.close()

if __name__=='__main__':
 def stop(*_):
  global STOP
  STOP=True
 for s in (signal.SIGTERM,signal.SIGINT):signal.signal(s,stop)
 raise SystemExit(main())
