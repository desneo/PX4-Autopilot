#!/usr/bin/env python3
import argparse,hashlib,json,math
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--world-file',type=Path);a=p.parse_args();folder=a.output
rows=[json.loads(line)for line in (folder/'model_truth.jsonl').read_text().splitlines()]
start=min(row['sim_time_s']for row in rows);end=max(row['sim_time_s']for row in rows)
report=dict(sim_time_range_s=[start,end],measured_sim_duration_s=end-start,models={},contact_pairs_last_5_sim_s={},all_rotor_contact_samples=0)
def tilt(row):
 w,x,y,z=row['quaternion_wxyz'];return math.degrees(math.acos(max(-1.,min(1.,1.-2*(x*x+y*y)))))
for name in ('rocket_two_axis_pod_1','rocket_two_axis_pod_2'):
 all_rows=[row for row in rows if row['model']==name];last=[row for row in all_rows if row['sim_time_s']>=end-5.]
 report['models'][name]=dict(samples=len(all_rows),final_position=all_rows[-1]['position'],final_tilt_deg=tilt(all_rows[-1]),
    all_tilt_range_deg=[min(map(tilt,all_rows)),max(map(tilt,all_rows))],last_5s_tilt_range_deg=[min(map(tilt,last)),max(map(tilt,last))],
    last_5s_max_movement_m=max(math.dist(row['position'],last[0]['position'])for row in last))
contact_file=folder/'contacts.jsonl'
if contact_file.exists():
 for line in contact_file.read_text().splitlines():
  row=json.loads(line)
  for contact in row['payload'].get('contact',[]):
   key=contact.get('collision1',{}).get('name','')+' vs '+contact.get('collision2',{}).get('name','')
   if '::rotor_'in key:report['all_rotor_contact_samples']+=1
   if row['sim_time_s']<end-5.:continue
   pair=report['contact_pairs_last_5_sim_s'].setdefault(key,dict(samples=0,max_depth_m=0.,max_force_n=0.,min_normal_z=1.,max_normal_z=-1.))
   pair['samples']+=1;pair['max_depth_m']=max(pair['max_depth_m'],max(contact.get('depth',[0.])))
   for normal in contact.get('normal',[]):
    pair['min_normal_z']=min(pair['min_normal_z'],normal.get('z',0.));pair['max_normal_z']=max(pair['max_normal_z'],normal.get('z',0.))
   for wrench in contact.get('wrench',[]):
    force=wrench.get('body_1_wrench',{}).get('force',{});pair['max_force_n']=max(pair['max_force_n'],math.sqrt(sum(force.get(axis,0.)**2 for axis in ('x','y','z'))))
report['healthy_for_flight']=all(x['final_tilt_deg']<=10. for x in report['models'].values()) and report['all_rotor_contact_samples']==0
report['required_20_sim_seconds_captured']=end-start>=20.
report['source_sha256']={str(Path(__file__)):hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
if a.world_file:report['source_sha256'][str(a.world_file)]=hashlib.sha256(a.world_file.read_bytes()).hexdigest()
(folder/'static_pose_assessment.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
