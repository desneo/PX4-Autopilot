#!/usr/bin/env python3
"""只读同步记录场景02电机命令、转子姿态差分和双机真值；绝不发布消息。"""
import argparse,json,math,os,signal,threading,time
from pathlib import Path
from gz.transport13 import Node
from gz.msgs10.pose_v_pb2 import Pose_V
from gz.msgs10.actuators_pb2 import Actuators
from gz.msgs10.scene_pb2 import Scene
from gz.msgs10.empty_pb2 import Empty
from gz.msgs10.contacts_pb2 import Contacts
from google.protobuf.json_format import MessageToDict
WORLD='geo_32_217857_119_105878'
MODELS=('rocket_two_axis_pod_1','rocket_two_axis_pod_2')
STOP=threading.Event()
def stamp(message):
 h=message.header.stamp
 return h.sec+h.nsec*1e-9

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--output',type=Path,required=True)
 p.add_argument('--duration',type=float,default=120)
 p.add_argument('--sim-duration',type=float)
 p.add_argument('--world',default=WORLD)
 args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
 global_world=args.world
 pose_time_range=[None,None]
 node=Node();lock=threading.Lock();last={};model_ids={};rotor_ids={};velocities={};counts={};files={}
 ready,scene=node.request(f'/world/{global_world}/scene/info',Empty(),Empty,Scene,5000)
 if not ready:raise RuntimeError('只读场景查询失败')
 for model in scene.model:
  if model.name not in MODELS:continue
  model_ids[model.id]=model.name
  for link in model.link:
   if link.name.startswith('rotor_'):
    rotor_ids[link.id]=(model.name,link.name)
 if len(model_ids)!=2 or len(rotor_ids)!=8:raise RuntimeError(f'实体不完整 {model_ids} {rotor_ids}')
 metadata=dict(world=global_world,partition=os.environ.get('GZ_PARTITION'),model_ids=model_ids,
               rotor_ids=rotor_ids,started_at_unix_s=time.time(),readonly=True,
               convention='dynamic_pose内link姿态为相对模型姿态；连续四元数绕局部Z差分为真实转子rad/s。motorVelocitySlowdownSim=10；命令rad/s除10才与物理关节转速相比较。')
 (args.output/'collection_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
 def write(kind,data):
  with lock:
   if kind not in files:files[kind]=(args.output/(kind+'.jsonl')).open('w')
   files[kind].write(json.dumps(data,ensure_ascii=False)+'\n')
   counts[kind]=counts.get(kind,0)+1
 def pose_cb(message):
  t=stamp(message);wall=time.time()
  if pose_time_range[0] is None:pose_time_range[0]=t
  pose_time_range[1]=t
  for pose in message.pose:
   if pose.id not in model_ids and pose.id not in rotor_ids:continue
   q=pose.orientation;v=pose.position
   row=dict(sim_time_s=t,wall_time_unix_s=wall,entity_id=pose.id,name=pose.name,
            position=[v.x,v.y,v.z],quaternion_wxyz=[q.w,q.x,q.y,q.z])
   if pose.id in rotor_ids:
    model,name=rotor_ids[pose.id];row.update(model=model,link=name)
    angle=2*math.atan2(q.z,q.w)
    if pose.id in last:
     pt,pa=last[pose.id];dt=t-pt
     if dt>0:
      da=math.atan2(math.sin(angle-pa),math.cos(angle-pa))
      row['joint_velocity_rad_s']=da/dt
      row['dt_sim_s']=dt
      velocities.setdefault(f'{model}/{name}',[]).append((t,da/dt))
    last[pose.id]=(t,angle)
   else:row['model']=model_ids[pose.id]
   write('rotor_pose' if pose.id in rotor_ids else 'model_truth',row)
 def command_cb(topic):
  def cb(message):
   write('motor_command',dict(topic=topic,wall_time_unix_s=time.time(),
               header_sim_time_s=stamp(message),payload=MessageToDict(message,preserving_proto_field_name=True)))
  return cb
 def contact_cb(topic):
  def cb(message):
   if message.contact:write('contacts',dict(topic=topic,wall_time_unix_s=time.time(),
                   sim_time_s=stamp(message),payload=MessageToDict(message,preserving_proto_field_name=True)))
  return cb
 topics=[f'/world/{global_world}/dynamic_pose/info']
 assert node.subscribe(Pose_V,topics[0],pose_cb)
 callbacks=[]
 for prefix in ('','/model'):
  topic=prefix+'/rocket_two_axis_pod_1/command/motor_speed';cb=command_cb(topic);callbacks.append(cb)
  assert node.subscribe(Actuators,topic,cb);topics.append(topic)
 contact_specs=[(model,'base_link',i) for model in MODELS for i in range(5)]
 contact_specs += [(model,f'rotor_{i}',7+3*i) for model in MODELS for i in range(4)]
 for model,link,i in contact_specs:
  topic=f'/world/{global_world}/model/{model}/link/{link}/sensor/scenario02_contact_{i}/contact'
  cb=contact_cb(topic);callbacks.append(cb);assert node.subscribe(Contacts,topic,cb);topics.append(topic)
 print('只读采集器已就绪 '+str(args.output),flush=True)
 started=time.monotonic()
 while not STOP.is_set() and time.monotonic()-started<args.duration:
  if args.sim_duration is not None and pose_time_range[0] is not None and pose_time_range[1]-pose_time_range[0]>=args.sim_duration:break
  time.sleep(.1)
 for topic in topics:node.unsubscribe(topic)
 del node
 time.sleep(.2)
 with lock:
  for f in files.values():f.close()
 def percentiles(items):
  values=sorted(abs(v) for _,v in items)
  return dict(samples=len(values),abs_min=values[0],abs_median=values[len(values)//2],abs_p95=values[min(len(values)-1,int(len(values)*.95))],abs_max=values[-1]) if values else {}
 summary=dict(metadata,finished_at_unix_s=time.time(),counts=counts,sim_time_range_s=pose_time_range,
              measured_sim_duration_s=pose_time_range[1]-pose_time_range[0] if pose_time_range[0] is not None else 0.,
              angular_velocity_rad_s={k:percentiles(v) for k,v in velocities.items()})
 (args.output/'collection_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':
 for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,lambda *_:STOP.set())
 main()
