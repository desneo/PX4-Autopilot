#!/usr/bin/env python3
"""场景02现成MAVSDK航线的独立真值记录与有界降落保护，仅--execute会控制。"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import threading
import time

ASSETS = Path('/home/aeroarx/zsh/px4-gazebo-assets')
PX4 = Path('/home/aeroarx/zsh/PX4-Autopilot')
SDK = Path('/home/aeroarx/zsh/MAVSDK')
BINARY = PX4/'scenarios/02_rocket_two_axis_pod/build/mavsdk_route_test'
LIBRARY = (SDK/'install/lib/libmavsdk.so').resolve()
sys.path.insert(0, str(ASSETS/'models/vehicles/rocket_racing_quad/tests'))
from gazebo_truth import nominal_cg_reference, world_reference_point

WORLD = 'geo_32_217857_119_105878'
MODELS = ['rocket_two_axis_pod_1', 'rocket_two_axis_pod_2']
SETTINGS = dict(route_edge_m=20., route_altitude_m=15., route_speed_m_s=5.,
                original_min_horizontal_m=12., original_min_altitude_m=8.,
                corner_tolerance_m=6., final_return_tolerance_m=3.,
                final_ground_height_tolerance_m=1., other_vehicle_motion_tolerance_m=.5,
                max_truth_gap_sim_s=.5, mavsdk_uri='udpin://0.0.0.0:14440',
                actual_mavsdk_bind_port=14540, guard_bind_port=14030,
                route_wall_timeout_s=720., recovery_wall_timeout_s=180.)
ABORT = threading.Event()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command_output(args):
    return subprocess.check_output(args, text=True).strip()


def require_free_ports():
    # 不使用SO_REUSEADDR，以免与已有控制端共享同一UDP端口。
    sockets=[]
    try:
        for port in (SETTINGS['actual_mavsdk_bind_port'],SETTINGS['guard_bind_port']):
            item=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            sockets.append(item)
            item.bind(('0.0.0.0',port))
    finally:
        for item in sockets:
            item.close()


def evaluate_truth(rows):
    grouped = {name: [row for row in rows if row['model'] == name] for name in MODELS}
    first, second = grouped.values()
    if len(first) < 20 or len(second) < 20:
        return dict(passed=False, error='两架飞机真值样本不足20条')
    origin = first[0]['nominal_cg_enu_m']
    relative = [([p-o for p,o in zip(row['nominal_cg_enu_m'], origin)], row['sim_time_s'])
                for row in first]
    climb = max(p[2] for p,_ in relative)
    travel = max(math.hypot(*p[:2]) for p,_ in relative)
    corners = [(0.,20.), (20.,20.), (20.,0.), (0.,0.)]
    corner_index, hits = 0, []
    for position, stamp in relative:
        if corner_index == len(corners) or position[2] < SETTINGS['original_min_altitude_m']:
            continue
        east, north = corners[corner_index]
        error = math.hypot(position[0]-east, position[1]-north)
        if error <= SETTINGS['corner_tolerance_m']:
            hits.append(dict(corner=corner_index+1, east_north_m=[east,north],
                             sim_time_s=stamp, error_m=error))
            corner_index += 1
    last = relative[-1][0]
    second_origin = second[0]['nominal_cg_enu_m']
    other_motion = max(math.dist(row['nominal_cg_enu_m'], second_origin) for row in second)
    max_gap = max(b['sim_time_s']-a['sim_time_s'] for data in grouped.values()
                  for a,b in zip(data,data[1:]))
    passed = (climb >= SETTINGS['original_min_altitude_m']
              and travel >= SETTINGS['original_min_horizontal_m'] and len(hits) == 4
              and math.hypot(*last[:2]) <= SETTINGS['final_return_tolerance_m']
              and abs(last[2]) <= SETTINGS['final_ground_height_tolerance_m']
              and other_motion <= SETTINGS['other_vehicle_motion_tolerance_m']
              and 0 < max_gap <= SETTINGS['max_truth_gap_sim_s'])
    return dict(passed=passed, sample_counts={name:len(data) for name,data in grouped.items()},
                max_climb_m=climb, max_horizontal_distance_m=travel, ordered_corner_hits=hits,
                final_return_distance_m=math.hypot(*last[:2]), final_relative_height_m=last[2],
                second_vehicle_max_motion_m=other_motion, max_truth_gap_sim_s=max_gap,
                reference='固定零关节名义CG；每条消息以实际机体四元数旋转偏移后取世界ENU位置')


class TruthRecorder:
    def __init__(self, runtime, output):
        from gz.transport13 import Node
        from gz.msgs10.pose_v_pb2 import Pose_V
        self.lock = threading.Lock()
        self.rows, self.last_stamp, self.references = [], {}, {}
        self.error = None
        self.path = output/'gazebo_truth.jsonl'
        self.stream = self.path.open('w')
        for index,name in enumerate(MODELS,1):
            config = runtime/f'generated/aircraft_{index}/rocket_two_axis_pod/parameters.json'
            self.references[name] = dict(config_path=str(config), config_sha256=sha(config),
                                        **nominal_cg_reference(json.loads(config.read_text())))
        self.node = Node()
        self.topic = f'/world/{WORLD}/dynamic_pose/info'
        if not self.node.subscribe(Pose_V, self.topic, self.receive):
            raise RuntimeError('真值话题订阅失败')

    def receive(self, message):
        stamp = message.header.stamp.sec+message.header.stamp.nsec*1e-9
        with self.lock:
            for pose in message.pose:
                if pose.name not in self.references:
                    continue
                previous = self.last_stamp.get(pose.name)
                if previous is not None and stamp < previous:
                    self.error = 'Gazebo仿真时间倒退'
                    continue
                if previous is not None and stamp-previous < .04-1e-9:
                    continue
                try:
                    point = world_reference_point(pose, self.references[pose.name]['body_offset_flu_m'])
                except ValueError as error:
                    self.error = str(error)
                    continue
                q,p = pose.orientation,pose.position
                row = dict(wall_time_unix_s=time.time(),sim_time_s=stamp,model=pose.name,
                           pose_position_enu_m=[p.x,p.y,p.z],quaternion_wxyz=[q.w,q.x,q.y,q.z],
                           nominal_cg_enu_m=point)
                self.rows.append(row)
                self.stream.write(json.dumps(row)+'\n')
                self.last_stamp[pose.name] = stamp
            self.stream.flush()

    def close(self):
        self.node.unsubscribe(self.topic)
        with self.lock:
            self.stream.close()


class FlightGuard:
    """只监听实例0的独立payload流，恢复时才发RTL/LAND，永不发disarm。"""
    def __init__(self, output):
        from pymavlink import mavutil
        self.mavutil = mavutil
        self.master = mavutil.mavlink_connection('udpin:0.0.0.0:14030',source_system=254)
        self.stream = (output/'mavlink_guard.jsonl').open('w')
        self.heartbeat = self.landed = None
        self.last_heartbeat = self.last_landed = 0.
        self.last_send = self.last_request = 0.
        self.ever_armed = False

    @property
    def armed(self):
        return bool(self.heartbeat and self.heartbeat.base_mode &
                    self.mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)

    @property
    def mode(self):
        return self.mavutil.interpret_px4_mode(self.heartbeat.base_mode,self.heartbeat.custom_mode) if self.heartbeat else 'UNKNOWN'

    def landed_disarmed(self):
        now = time.monotonic()
        return (self.heartbeat is not None and not self.armed and now-self.last_heartbeat < 3
                and self.landed == self.mavutil.mavlink.MAV_LANDED_STATE_ON_GROUND
                and now-self.last_landed < 3)

    def step(self):
        now = time.monotonic()
        if now-self.last_send >= 1:
            self.master.mav.heartbeat_send(self.mavutil.mavlink.MAV_TYPE_GCS,
                self.mavutil.mavlink.MAV_AUTOPILOT_INVALID,0,0,0)
            self.last_send = now
        for _ in range(200):
            message = self.master.recv_match(blocking=False)
            if message is None:
                break
            if message.get_srcSystem() != 1 or message.get_srcComponent() != 1:
                continue
            kind = message.get_type()
            if kind == 'HEARTBEAT':
                if message.autopilot != self.mavutil.mavlink.MAV_AUTOPILOT_PX4:
                    continue
                self.heartbeat,self.last_heartbeat = message,now
                self.ever_armed |= self.armed
            elif kind == 'EXTENDED_SYS_STATE':
                self.landed,self.last_landed = message.landed_state,now
            if kind in ('HEARTBEAT','EXTENDED_SYS_STATE','COMMAND_ACK','STATUSTEXT'):
                self.stream.write(json.dumps(dict(wall_time_unix_s=time.time(),
                                                payload=message.to_dict()))+'\n')
        if self.heartbeat and now-self.last_request >= 2:
            self.master.mav.command_long_send(1,1,self.mavutil.mavlink.MAV_CMD_SET_MESSAGE_INTERVAL,
                                             0,245,500000,0,0,0,0,0)
            self.last_request = now
        self.stream.flush()
        time.sleep(.02)

    def recover(self, process):
        """先让PX4进入RTL/LAND，再停测试进程，继续等待落地；整体180秒有界。"""
        started,next_command = time.monotonic(),0.
        mode_confirmed = False
        while time.monotonic()-started < SETTINGS['recovery_wall_timeout_s']:
            self.step()
            if self.landed_disarmed():
                return dict(passed=True,landed_disarmed=True,elapsed_wall_s=time.monotonic()-started)
            now = time.monotonic()
            if now >= next_command:
                landing = now-started >= 20
                command = (self.mavutil.mavlink.MAV_CMD_NAV_LAND if landing
                           else self.mavutil.mavlink.MAV_CMD_NAV_RETURN_TO_LAUNCH)
                coordinates = (float('nan'),)*3 if landing else (0.,)*3
                self.master.mav.command_long_send(1,1,command,0,0,0,0,0,*coordinates)
                self.stream.write(json.dumps(dict(wall_time_unix_s=time.time(),
                    recovery_command='LAND' if landing else 'RTL'))+'\n')
                next_command = now+2
            if self.mode in ('RTL','LAND') and now-self.last_heartbeat < 3:
                mode_confirmed = True
                if process is not None and process.poll() is None:
                    process.terminate()
        return dict(passed=False,landed_disarmed=False,mode=self.mode,
                    autonomous_recovery_mode_confirmed=mode_confirmed,
                    control_process_preserved=bool(process is not None and process.poll() is None),
                    error='有界RTL/LAND恢复未确认落地，必须检查本机仿真；未终止PX4')

    def close(self):
        self.master.close()
        self.stream.close()


def selftest():
    import io
    from types import SimpleNamespace
    from pymavlink import mavutil
    def row(name,stamp,point):
        return dict(model=name,sim_time_s=stamp,nominal_cg_enu_m=point)
    points = [(0,0,0),(0,0,15),(0,20,15),(20,20,15),(20,0,15),(0,0,15),(0,0,0)]
    rows=[]
    for index in range(180):
        segment=min(index//30,5);fraction=(index%30)/29
        point=[a+(b-a)*fraction for a,b in zip(points[segment],points[segment+1])]
        rows += [row(MODELS[0],index*.1,point),row(MODELS[1],index*.1,[5,0,0])]
    assert evaluate_truth(rows)['passed']
    assert not evaluate_truth([dict(r,nominal_cg_enu_m=[0,0,0]) if r['model']==MODELS[0] else r for r in rows])['passed']
    assert not evaluate_truth([dict(r,nominal_cg_enu_m=[10,0,0]) if r['model']==MODELS[1] and r['sim_time_s']>5 else r for r in rows])['passed']
    for confirms_mode,lands in ((True,True),(False,False)):
        class FakeGuard:
            clock=0.
            mode='MISSION'
            last_heartbeat=0.
            stream=io.StringIO()
            requested=False
            def command(self,*_):
                self.requested=True
            def step(self):
                self.clock+=1
                self.last_heartbeat=self.clock
                if self.requested and confirms_mode:
                    self.mode='RTL'
            def landed_disarmed(self):
                return lands and self.requested and self.clock>=5
        guard=FakeGuard()
        guard.mavutil=mavutil
        guard.master=SimpleNamespace(mav=SimpleNamespace(command_long_send=guard.command))
        class FakeProcess:
            terminated=False
            def poll(self):
                return -15 if self.terminated else None
            def terminate(self):
                assert guard.mode in ('RTL','LAND'), '未确认自主恢复模式前不得终止控制器'
                self.terminated=True
        process=FakeProcess()
        real_monotonic=time.monotonic
        try:
            time.monotonic=lambda:guard.clock
            recovery=FlightGuard.recover(guard,process)
        finally:
            time.monotonic=real_monotonic
        assert recovery['passed']==lands
        assert process.terminated==confirms_mode
    print('真值判据与恢复顺序自测通过；未创建任何网络连接或控制进程')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--selftest',action='store_true')
    parser.add_argument('--runtime',type=Path,default=Path('/tmp/px4-scenarios/02_rocket_two_axis_pod'))
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args()
    if args.selftest:
        selftest();return 0
    if not args.execute:
        parser.error('只有显式--execute才会启动既有MAVSDK航线测试')
    args.output.mkdir(parents=True,exist_ok=True)
    report=dict(passed=False,started_at_unix_s=time.time(),settings=SETTINGS,
                source_sha256={str(p):sha(p) for p in (BINARY,LIBRARY,Path(__file__),
                    PX4/'scenarios/02_rocket_two_axis_pod/mavsdk_route_test.cpp',
                    ASSETS/'models/vehicles/rocket_racing_quad/tests/gazebo_truth.py',
                    args.runtime/'world.sdf')},sdk_commit=command_output(['git','-C',str(SDK),'rev-parse','HEAD']),
                asset_commit=command_output(['git','-C',str(ASSETS),'rev-parse','HEAD']))
    guard=truth=process=None
    log=None
    try:
        require_free_ports()
        guard=FlightGuard(args.output)
        deadline=time.monotonic()+30
        while not guard.landed_disarmed():
            guard.step()
            if guard.armed:
                raise RuntimeError('实例1已解锁，拒绝接管；未启动航线程序')
            if time.monotonic()>deadline or ABORT.is_set():
                raise RuntimeError('未收到新鲜实例1未解锁/ON_GROUND状态，未启动航线')
        truth=TruthRecorder(args.runtime,args.output)
        deadline=time.monotonic()+10
        while len(truth.last_stamp)<2:
            guard.step()
            if guard.armed or time.monotonic()>deadline or ABORT.is_set():
                raise RuntimeError('真值就绪前状态改变或缺少双机真值，未启动航线')
        report['measurement_references']=truth.references
        log=(args.output/'mavsdk_route.log').open('w')
        env=dict(os.environ,LD_LIBRARY_PATH=str(SDK/'install/lib'))
        process=subprocess.Popen([str(BINARY),SETTINGS['mavsdk_uri']],stdout=log,
                                 stderr=subprocess.STDOUT,env=env,start_new_session=True)
        report['mavsdk_pid']=process.pid
        print(f'MAVSDK航线已启动 pid={process.pid}，独立保护监听14030；真值记录{truth.path}',flush=True)
        started=time.monotonic()
        while process.poll() is None:
            guard.step()
            if truth.error:
                raise RuntimeError(truth.error)
            if time.monotonic()-guard.last_heartbeat>5:
                raise RuntimeError('独立保护心跳超过5秒未更新，进入有界自主降落恢复')
            if ABORT.is_set():
                raise RuntimeError('收到停止请求，进入有界自主降落恢复')
            if time.monotonic()-started>SETTINGS['route_wall_timeout_s']:
                raise RuntimeError('航线程序超过墙钟期限，进入有界自主降落恢复')
        report['mavsdk_exit_code']=process.returncode
        if process.returncode != 0 or not guard.landed_disarmed():
            raise RuntimeError('MAVSDK返回失败或尚未确认落地停机')
        settle=time.monotonic()+3
        while time.monotonic()<settle:
            guard.step()
        report['landing_confirmed']=guard.landed_disarmed()
        with truth.lock:
            report['truth_validation']=evaluate_truth(list(truth.rows))
        report['passed']=report['landing_confirmed'] and report['truth_validation']['passed']
    except Exception as error:
        report['error']=str(error)
        if guard is not None and process is not None and not guard.landed_disarmed():
            report['recovery']=guard.recover(process)
    finally:
        if process is not None and process.poll() is None and guard is not None and guard.landed_disarmed():
            process.terminate()
        if process is not None and process.poll() is not None:
            process.wait()
        if truth is not None:
            truth.close()
        if guard is not None:
            guard.close()
        if log is not None:
            log.close()
        report['finished_at_unix_s']=time.time()
        report['abort_requested']=ABORT.is_set()
        (args.output/'flight_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
    return 0 if report['passed'] else 1


if __name__=='__main__':
    for sig in (signal.SIGINT,signal.SIGTERM):
        signal.signal(sig,lambda *_:ABORT.set())
    raise SystemExit(main())
