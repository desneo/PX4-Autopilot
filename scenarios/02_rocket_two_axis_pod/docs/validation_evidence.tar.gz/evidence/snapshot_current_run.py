from pathlib import Path
import hashlib,json,subprocess,time,sys,xml.etree.ElementTree as E
root=Path('/home/aeroarx/zsh/PX4-Autopilot');assets=Path('/home/aeroarx/zsh/px4-gazebo-assets');runtime=Path('/tmp/px4-scenarios/02_rocket_two_axis_pod');out=Path(sys.argv[1])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(p):return subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()
old=json.loads(Path('/tmp/scenario02_motion_head_5a29c7e/execution_snapshot.json').read_text())
scene=root/'scenarios/02_rocket_two_axis_pod'
d=dict(captured_at_unix_s=time.time(),assets_commit=git(assets),px4_commit=git(root),scene_source_sha256={str(p.relative_to(root)):sha(p) for p in scene.rglob('*') if p.suffix in ('.py','.sh','.cc','.hh') and 'build' not in p.parts},binary_sha256={p:sha(Path(p)) for p in old['binary_sha256']},runtime_world_sha256=sha(runtime/'world.sdf'),aircraft=[])
w=E.parse(runtime/'world.sdf').find('world')
d['mesh_collision_count']=len(w.findall("plugin[@name='scenario02::CollisionMonitor']/mesh_collision"))
for i in (1,2):
 p=runtime/f'generated/aircraft_{i}/rocket_two_axis_pod'
 m=w.find(f"model[@name='rocket_two_axis_pod_{i}']")
 d['aircraft'].append(dict(aircraft_id=i,runtime_manifest=json.loads((p/'manifest.json').read_text()),runtime_model_sha256=sha(p/'model.sdf'),world_pose=m.findtext('pose'),physical_mesh_collisions=len(m.findall('link/collision/geometry/mesh')),contact_sensors=len(m.findall("link/sensor[@type='contact']"))))
d['preserved_msg_sha256']=sha(root/'msg/DytAishengTelemetry.msg')
out.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(out); print('world',d['runtime_world_sha256']);print('models',[a['world_pose'] for a in d['aircraft']])
