from pathlib import Path
import copy,hashlib,json,sys,xml.etree.ElementTree as ET
asset=Path('/home/aeroarx/zsh/px4-gazebo-assets')
runtime=Path('/tmp/px4-scenarios/02_rocket_two_axis_pod')
sys.path.insert(0,str(asset/'assembledmodels/rocket_two_axis_pod/tools'))
import check_dynamic_model as check
world=ET.parse(runtime/'world.sdf').getroot().find('world')
monitor=world.find("plugin[@name='scenario02::CollisionMonitor']")
bounds=monitor.findall('mesh_collision')
assert len(bounds)==18
result={'assets_revision':(runtime/'assets_revision').read_text().strip(),'aircraft':[],'mesh_bounds_count':len(bounds)}
assert result['assets_revision']=='5a29c7eef09a'
for i in (1,2):
    output=runtime/f'generated/aircraft_{i}/rocket_two_axis_pod'
    manifest=json.loads((output/'manifest.json').read_text())
    mass=check.check_output(output,manifest)
    source=ET.parse(output/'model.sdf').getroot().find('model')
    actual=copy.deepcopy(world.find(f"model[@name='rocket_two_axis_pod_{i}']"))
    spawn=actual.findtext('pose'); actual.remove(actual.find('pose'))
    actual.set('name','rocket_two_axis_pod')
    contacts=0
    for link in actual.findall('link'):
        collision_names={c.get('name') for c in link.findall('collision')}
        for sensor in list(link.findall('sensor')):
            if sensor.get('name','').startswith('scenario02_contact_'):
                assert sensor.get('type')=='contact' and sensor.findtext('contact/collision') in collision_names
                assert sensor.findtext('update_rate')=='250'
                contacts+=1; link.remove(sensor)
    assert contacts==26
    for model in (source,actual):
        for uri in model.findall('.//uri'):
            value=(uri.text or '').strip().removeprefix('file://')
            prefix='model://rocket_two_axis_pod/'
            path=output/value.removeprefix(prefix) if value.startswith(prefix) else Path(value)
            assert path.is_absolute() and path.is_file(),str(path)
            uri.text='sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()
    assert check.canonical(source)==check.canonical(actual),'世界中飞机内容偏离生成资产'
    meshkeys={(f'rocket_two_axis_pod_{i}',link.get('name'),c.get('name')) for link in actual.findall('link') for c in link.findall('collision') if c.find('geometry/mesh') is not None}
    configkeys={(b.findtext('model'),b.findtext('link'),b.findtext('collision')) for b in bounds if b.findtext('model')==f'rocket_two_axis_pod_{i}'}
    assert meshkeys==configkeys and len(meshkeys)==9
    marker=world.find(f"model[@name='POD_LOCATION_MARKER_{i}']")
    assert marker is not None and not marker.findall('.//collision')
    result['aircraft'].append(dict(id=i,mass_kg=mass,links=len(actual.findall('link')),joints=len(actual.findall('joint')),physical_mesh_collisions=len(meshkeys),native_contact_sensors=contacts,spawn=spawn,source_fingerprints=manifest['source_sha256'],world_content_matches_generated=True,noncolliding_marker=marker.get('name')))
generated=runtime/'generated/aircraft_1/rocket_two_axis_pod/px4/4023_gz_rocket_two_axis_pod'
active=runtime/'etc/init.d-posix/airframes/4023_gz_rocket_two_axis_pod'
a=generated.read_text().splitlines(); b=active.read_text().splitlines()
assert len(a)==len(b)
differences=[dict(generated=x,actual=y) for x,y in zip(a,b) if x!=y]
assert differences==[dict(generated='param set-default EKF2_HGT_REF 0',actual='param set-default EKF2_HGT_REF 1')],differences
result['existing_scene_runtime_airframe_override']=differences
result['passed']=True
path=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/scenario02_motion_head_5a29c7e/inheritance_audit.json')
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v if k!='aircraft' else [{p:q for p,q in x.items() if p!='source_fingerprints'} for x in v] for k,v in result.items()},ensure_ascii=False,indent=2))
